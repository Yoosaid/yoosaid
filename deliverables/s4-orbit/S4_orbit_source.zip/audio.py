import wave, math, random, struct, os
random.seed(4);sr=48000;out=[]
for i in range(sr*3):
 t=i/sr;n=random.uniform(-1,1)
 impact=.28*math.exp(-t*25)*(math.sin(math.tau*(95*t-12*t*t))+.45*n)
 swell=.035*math.sin(math.pi*t/3)**2*(math.sin(math.tau*110*t)+.5*math.sin(math.tau*165*t))
 air=.025*n*math.sin(math.pi*t/3)**2
 fade=min(1,(3-t)*8)
 v=(impact+swell+air)*fade;pan=.35*math.sin(t*math.pi/3)
 out.append(struct.pack('<hh',int(32767*v*(1-pan)),int(32767*v*(1+pan))))
with wave.open(os.path.join(os.path.dirname(__file__),'orbit_sound.wav'),'wb') as w:
 w.setparams((2,2,sr,0,'NONE','not compressed'));w.writeframes(b''.join(out))
