import bpy,json,os
from mathutils import Vector
s=bpy.context.scene;results=[]
for f in range(1,73):
 s.frame_set(f);bpy.context.view_layer.update();cam=s.camera;target=bpy.data.objects['Hand scooped strawberry'].matrix_world.translation
 hit,loc,norm,idx,obj,matrix=s.ray_cast(bpy.context.evaluated_depsgraph_get(),cam.location,(target-cam.location).normalized(),distance=(target-cam.location).length)
 assert not hit or not obj.name.startswith(('Pastel','Window','Shop','Tree')), (f,obj.name)
 results.append({'frame':f,'first_surface':obj.name if hit else None})
json.dump(results,open(os.path.join(os.path.dirname(bpy.data.filepath),'occlusion_checks.json'),'w'),indent=2)
print('PASS: no street geometry blocks the scoop center in all 72 frames')
