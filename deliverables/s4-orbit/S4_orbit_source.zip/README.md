# ICE CREAM — S4 Orbit technical test

This deliverable covers S4 only: 3 seconds, 72 frames at 24 fps, 1920×1080 H.264 with original synthesized stereo sound. It is not the full walking/drop/resume film.

## Run

Requires Blender 4.3.2, Python 3 and FFmpeg (already available in this environment).

```bash
cd /workspace/icecream-orbit
./render.sh
```

Open `icecream_orbit.blend` in Blender to inspect the scene. `scene.py` rebuilds it deterministically; `audio.py` generates the restrained freeze impact and orbit atmosphere. No external assets, paid dependencies or credentials are needed. Rendering is CPU based, with 4 threads and Eevee at 8 temporal samples (this Blender build lacks OpenImageDenoise). The output is `S4_orbit_test.mp4`.

## What is genuinely spatial

The perspective camera travels 195 degrees around a static world-space focus. Only the camera is animated. The scoop, tapered cone, raised waffle lattice, berry flecks, melt lobes and airborne droplets are meshes/curves with real depth. The street, windows and trees are spatial geometry, not a rotating background plate. Camera elevation descends during the orbit. Depth of field separates the subject from the street.

`camera_validation.json` records each camera position and the list of animated objects. Inspect frames 1, 36 and 72 to compare visible faces and occlusion. No object spin, whole-frame rotation or image warp substitutes for the orbit.

## Art limitations

This is a procedural, stylized 3D interpretation of the supplied pink ice cream and sunlit street reference. It does not reproduce the reference's hand-painted detail exactly. Character design and walking have intentionally not been attempted in this S4 technical test. The sound is an original procedural sketch, not final music or a commercial sound library. Approval of the visual direction is a separate artistic judgment from the spatial checks.

## Measured geometry checks

The sampled frames (1, 18, 36, 54, 72) show the hero spanning 80.3–83.1% of image height. The camera travels 195.000 degrees. Only the camera has animation data; frozen droplets and the scene remain static. This framing percentage refers to image height, not total pixel area. `geometry_checks.json` contains camera coordinates and projected bounds.

All 72 camera positions additionally passed a ray-cast test: no street building or tree blocks the line of sight to the scoop center. The street was widened after detecting an initial camera/building intersection.

The MP4 encoding applies a mild gamma/brightness/saturation grade in FFmpeg; raw Blender PNGs remain ungraded. The exact filter is retained in render.sh.
