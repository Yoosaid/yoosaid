import bpy, json, math, os
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector
s=bpy.context.scene
animated=[o.name for o in s.objects if o.animation_data]
assert animated==['TRUE 195 degree orbit camera'],animated
assert s.frame_end==72 and s.render.fps==24
hero=bpy.data.objects['FROZEN ice cream assembly']
report={'animated_objects':animated,'frames':72,'fps':24,'sampled_frames':[]}
for f in [1,18,36,54,72]:
 s.frame_set(f);bpy.context.view_layer.update()
 pts=[]
 for ob in hero.children:
  if ob.type=='MESH':
   pts.extend(world_to_camera_view(s,s.camera,ob.matrix_world@v.co) for v in ob.data.vertices)
 xs=[v.x for v in pts];ys=[v.y for v in pts]
 report['sampled_frames'].append({'frame':f,'camera':list(s.camera.location),'height_fraction':max(ys)-min(ys),'screen_bounds':[min(xs),min(ys),max(xs),max(ys)]})
angles=[]
for f in [1,72]:
 s.frame_set(f);angles.append(math.degrees(math.atan2(s.camera.location.y,s.camera.location.x)))
report['orbit_degrees']=(angles[1]-angles[0])%360
assert abs(report['orbit_degrees']-195)<.001
path=os.path.join(os.path.dirname(bpy.data.filepath),'geometry_checks.json')
json.dump(report,open(path,'w'),indent=2);print(json.dumps(report,indent=2))
