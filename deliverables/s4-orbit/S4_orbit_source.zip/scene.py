import bpy, math, random, os, json
from mathutils import Vector, noise
random.seed(19)
ROOT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
s=bpy.context.scene
s.render.engine='BLENDER_EEVEE_NEXT'; s.eevee.taa_render_samples=8; s.cycles.use_denoising=False
s.render.resolution_x=1920;s.render.resolution_y=1080;s.render.resolution_percentage=100
s.render.fps=24;s.frame_start=1;s.frame_end=72
s.world.color=(.32,.42,.55)
s.view_settings.view_transform='AgX'
def mat(name,col,rough=0.65):
 m=bpy.data.materials.new(name); m.diffuse_color=(*col,1);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Roughness'].default_value=rough
 return m
pink=mat('Strawberry cream',(.94,.29,.39)); waffle=mat('Golden baked wafer',(.58,.245,.065));ridge=mat('Raised waffle edges',(.85,.45,.15));seed=mat('Strawberry flecks',(.5,.045,.095))
p=pink.node_tree.nodes.get('Principled BSDF');p.inputs['Subsurface Weight'].default_value=.065
n=pink.node_tree.nodes.new('ShaderNodeTexNoise');n.inputs['Scale'].default_value=32;n.inputs['Detail'].default_value=3
b=pink.node_tree.nodes.new('ShaderNodeBump');b.inputs['Strength'].default_value=.23;b.inputs['Distance'].default_value=.045
pink.node_tree.links.new(n.outputs['Fac'],b.inputs['Height']);pink.node_tree.links.new(b.outputs['Normal'],p.inputs['Normal'])
def uv(name,loc,scale,ma,seg=32,rings=20):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=seg,ring_count=rings,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(ma)
 for f in o.data.polygons:f.use_smooth=True
 return o
def curve(name,points,r,ma):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.bevel_depth=r;c.bevel_resolution=2
 sp=c.splines.new('POLY');sp.points.add(len(points)-1)
 for p,co in zip(sp.points,points):p.co=(*co,1)
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.data.materials.append(ma);return o
hero=bpy.data.objects.new('FROZEN ice cream assembly',None);bpy.context.collection.objects.link(hero)
def attach(o):o.parent=hero;return o
bpy.ops.mesh.primitive_cone_add(vertices=96,radius1=.035,radius2=.57,depth=1.75,location=(0,0,-.56));o=bpy.context.object;o.name='Solid tapered wafer';o.data.materials.append(waffle);attach(o)
for sign in [-1,1]:
 for j in range(22):
  pts=[]
  for k in range(100):
   t=.035+.965*k/99;z=-1.435+1.75*t;r=.035+.535*t+.006;a=j*2*math.pi/22+sign*3.4*math.log(t)
   pts.append((r*math.cos(a),r*math.sin(a),z))
  attach(curve('Physical diagonal waffle lattice',pts,.012,ridge))
o=attach(uv('Hand scooped strawberry', (0,0,.69),(.79,.75,.76),pink,96,64))
for v in o.data.vertices:
 co=v.co;co*=1+.065*noise.noise_vector(co*4.2)[0]+.026*noise.noise_vector(co*13)[1]
for j in range(14):
 a=j*math.tau/14;r=.58
 attach(uv('Scalloped melting scoop edge',(r*math.cos(a),r*math.sin(a),.28+random.uniform(-.09,.06)),(.23,.23,random.uniform(.18,.30)),pink))
for j in range(240):
 z=random.uniform(-.8,1);a=random.uniform(0,math.tau);r=math.sqrt(1-z*z);q=Vector((r*math.cos(a),r*math.sin(a),z));co=(q.x*.792,q.y*.755,.69+q.z*.763)
 ob=attach(uv('Embedded berry speck',co,(.012,.012,random.uniform(.013,.03)),seed,8,6));ob.rotation_euler=q.to_track_quat('Z','Y').to_euler()
for j in range(4):
 a=j*1.7+.3;x=.58*math.cos(a);y=.58*math.sin(a)
 attach(uv('Soft melt tongue',(x,y,.12),(.115,.12,.32 if j==1 else .18),pink))
hero.location=(0,0,2.15);hero.rotation_euler=(math.radians(-12),math.radians(32),math.radians(-15))
for j in range(17):
 a=random.uniform(0,math.tau);r=random.uniform(1.0,1.75)
 ob=uv('Frozen airborne drop %02d'%j,(r*math.cos(a),r*math.sin(a),random.uniform(.9,3.35)),(.06,.06,random.uniform(.06,.14)),pink,20,12);ob.rotation_euler=(random.random(),random.random(),random.random())
# Spatial street set: real geometry, never a screen-space background.
cream=mat('Warm plaster',(.83,.64,.39));coral=mat('Peach plaster',(.8,.39,.27));teal=mat('Teal shop fronts',(.045,.26,.28));glass=mat('Blue glass',(.12,.28,.36));paving=mat('Sunlit limestone',(.67,.53,.37));leaf=mat('Summer foliage',(.16,.36,.14))
def cube(name,loc,scale,ma,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma)
 if bevel: mod=o.modifiers.new('Soft graphic corners','BEVEL');mod.width=bevel;mod.segments=2;o.modifiers.new('Normals','WEIGHTED_NORMAL')
 return o
cube('Street',(0,0,-.18),(100,100,.3),paving)
for x in range(-15,16,2):
 for y in range(-15,16,2):cube('Pavement seams',(x,y,-.022),(1.985,1.985,.035),paving,.025)
for side in [-1,1]:
 for i in range(-4,5):
  x=side*13;y=i*4.4;h=random.uniform(9,14);ma=[cream,coral][i%2]
  cube('Pastel street facade',(x,y,h/2),(3,4.25,h),ma,.08)
  for z in [2,5.3,8.4,11.4]:
   for yy in [-1,1]:
    cube('Window frame',(x-side*1.54,y+yy,z),(.15,1.35,1.8),teal,.035)
    cube('Window glass',(x-side*1.64,y+yy,z),(.05,1.08,1.5),glass)
  cube('Shop canopy',(x-side*1.95,y,3.6),(1.2,3.9,.17),cream,.04)
 for y in [-10,-3,5,12]:
  cube('Tree trunk',(side*10.5,y,2),(.24,.24,4),waffle)
  for j in range(5):uv('Tree canopy',(side*10.5+random.uniform(-.7,.7),y+random.uniform(-.7,.7),4+random.uniform(0,1)),(1.1,1.1,1.25),leaf,16,10)
world=s.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.31,.58,.84,1);world.node_tree.nodes['Background'].inputs[1].default_value=.45
bpy.ops.object.light_add(type='AREA',location=(-3,-4,9));bpy.context.object.data.energy=1500;bpy.context.object.data.shape='DISK';bpy.context.object.data.size=6
bpy.ops.object.light_add(type='SUN',location=(0,0,9));bpy.context.object.rotation_euler=(.4,-.5,-.6);bpy.context.object.data.energy=2;bpy.context.object.data.angle=.12
focus=bpy.data.objects.new('Static focus point',None);bpy.context.collection.objects.link(focus);focus.location=(0,0,2.35)
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='TRUE 195 degree orbit camera';s.camera=cam;cam.data.lens=48;cam.data.dof.use_dof=True;cam.data.dof.focus_object=focus;cam.data.dof.aperture_fstop=3.2
record=[]
for f in range(1,73):
 t=(f-1)/71;u=t*t*(3-2*t);a=math.radians(-100+195*u);r=7.45-.15*math.sin(math.pi*t)
 cam.location=(r*math.cos(a),r*math.sin(a),3.05-.85*u);cam.rotation_euler=(focus.location-cam.location).to_track_quat('-Z','Y').to_euler();cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f)
 record.append({'frame':f,'azimuth_degrees':-100+195*u,'camera_location':list(cam.location)})
s.render.image_settings.file_format='PNG';s.render.filepath=ROOT+'/frames/'
s.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=ROOT+'/icecream_orbit.blend')
json.dump({'orbit_degrees':195,'fps':24,'frames':72,'animated_objects':[o.name for o in s.objects if o.animation_data],'camera':record},open(ROOT+'/camera_validation.json','w'),indent=2)
if os.getenv('PREVIEW'):
 s.render.resolution_percentage=50;s.cycles.samples=12;s.render.filepath=ROOT+'/preview.png';bpy.ops.render.render(write_still=True)
else:bpy.ops.render.render(animation=True)
