#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p frames
export MESA_SHADER_CACHE_DIR="$PWD/.cache"
export LP_NUM_THREADS=4
mkdir -p "$MESA_SHADER_CACHE_DIR"
blender -b -t 4 --python scene.py
python3 audio.py
ffmpeg -y -framerate 24 -i frames/%04d.png -i orbit_sound.wav -vf 'eq=gamma=1.12:saturation=1.18:brightness=0.015' -c:v libx264 -crf 18 -preset medium -pix_fmt yuv420p -c:a aac -b:a 192k -shortest -movflags +faststart S4_orbit_test.mp4
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate -show_entries format=duration -of json S4_orbit_test.mp4
